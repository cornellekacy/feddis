<?php $link = mysqli_connect("localhost", "root", "", "track1"); ?>

<?php
// $mysqli = new mysqli("localhost","azuerbxxqq","W239ejZRrp","azuerbxxqq");

// // Check connection
// if ($mysqli -> connect_errno) {
//   echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
//   exit();
// }
// ?>