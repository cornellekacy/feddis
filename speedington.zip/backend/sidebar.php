
<!-- End header header -->
<!-- Left Sidebar  -->
<div class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-devider"></li>
                <li class="nav-label">Home</li>
                <li> <a  href="home.php" aria-expanded="false"><i class="fa fa-tachometer"></i>Dashboard</a>
                </li>
                <li> <a  href="add_user.php" aria-expanded="false"><i class="fa fa-users"></i>New User</a>

                </li>
                <li> <a  href="view_user.php" aria-expanded="false"><i class="fa fa-eye"></i>View Users</a>

                </li>
                <li> <a  href="new_tracking.php" aria-expanded="false"><i class="fa fa-bar-chart"></i>New Tracking</a>
                </li>
                <li> <a  href="view_tracking.php" aria-expanded="false"><i class="fa fa-eye"></i>View Tracking</a>

                </li>
                <li> <a  href="mail.php" aria-expanded="false"><i class="fa fa-eye"></i>Mail Jk</a>

                </li>
                 <li> <a  href="editmap.php" aria-expanded="false"><i class="fa fa-eye"></i>Edit Map</a>
                  <!--   <li> <a  href="shipment.php" aria-expanded="false"><i class="fa fa-eye"></i>Package Locations</a>

                </li> -->
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</div>